%% =================================================================
% This script compares transform-based tensor nuclear norm (TNN) methods for low-rank tensor completion
% listed as follows:
%     1. TNN           t-SVD base-line method
%     2. UTNN          unitary tranform-based TNN method
%     3. FTNN          framelet transform-based TNN method
%     4. NTTNN         nonlinear transform-based TNN method
%
% References: 
% [1] C. Lu, J. Feng, Y. Chen, W. Liu, Z. Lin and S. Yan, 
% "Tensor Robust Principal Component Analysis with a New Tensor Nuclear Norm" ,
% in IEEE Transactions on Pattern Analysis and Machine Intelligence, vol. 42, no. 4, pp. 925-938, 2020.
% [2] G.-J. Song, M. K. Ng, and X.-J. Zhang, "Robust tensor completion
% using transformed tensor singular value decomposition", Numerical Linear
% Algebra with Applications, vol. 27, p. e2299, 2020.
% [3] T.-X. Jiang, M. K. Ng, X.-L. Zhao and T.-Z. Huang, 
% "Framelet Representation of Tensor Nuclear Norm for Third-Order Tensor Completion",
% IEEE Transactions on Image Processing, vol. 29, pp. 7233-7244, 2020.
% [4] B.-Z. Li, X.-L Zhao, T.-Y. Ji, X.-J. Zhang, and T.-Z. Huang, 
% "Nonlinear Transform Induced Tensor Nuclear Norm for Tensor Completion",
% Journal of Scientific Computing, vol. 92, no. 3, 2020.
% You can:
%     1. Type 'Demo' to to run various methods and see the pre-computed results.
%     2. Select competing methods by turn on/off the enable-bits in Demo.m
% Please make sure your data is in range [0, 1].
%
% Created by Ben-Zheng Li ��lbz1604179601@126.com��
% 29/4/2023

%% =================================================================
%clc;
clear;
close all;
addpath(genpath('data'));
addpath(genpath('lib'));
addpath(genpath('methods'));
CurrentPath = pwd;

%% Set enable bits
EN_TNN        = 1;
EN_UTNN       = 1;
EN_FTNN       = 1;
EN_NTTNN      = 1;
methodname    = {'Observed','TNN','UTNN','FTNN','NTTNN'};
Mnum          = length(methodname);
Re_tensor     =  cell(Mnum,1);
MPSNRALL      =  zeros(Mnum,1);
SSIMALL       =  zeros(Mnum,1);
time          =  zeros(Mnum,1);

%% Load initial data
for tensor_num= 1
    switch tensor_num
        case 1
        load('hall.mat');
        Y_tensorT = X;
        case 2
        load('carphone.mat');
        Y_tensorT = X;
        case 3
        load('container.mat');
        Y_tensorT = X;
    end
fprintf('SR   & Method  & MPSNR   & MSSIM  & MFSIM  & Time  \\\\ \\hline \n');
%% Sampling with random position
for sample_ratio = [0.1]
        fprintf('\n');
        fprintf('================Results=p=%f======================\n',sample_ratio);
        Y_tensorT   = X;
        [n1,n2,n3]  = size(Y_tensorT);
        Ndim        = ndims(Y_tensorT);
        Nway        = size(Y_tensorT);
        rand('state',0);
        Omega       = find(rand(prod(Nway),1)<sample_ratio);
        Ind         = zeros(size(Y_tensorT));
        Ind(Omega)  = 1;
        Y_tensor0   = zeros(Nway);
        Y_tensor0(Omega) = Y_tensorT(Omega);
 %%
        i  = 1;
        Re_tensor{i} = Y_tensor0;
        [MPSNRALL(i), SSIMALL(i)] = quality(Y_tensorT*255, Re_tensor{i}*255);
        time(i) = 0;
        enList = 1;
        fprintf(' %8.8s    %5.4s    %5.4s  %5.4s   %5.4s \n','method','PSNR', 'SSIM','iter','time');
        fprintf(' %8.8s    %5.3f    %5.4f    %3.3d     %.1f \n',...
            methodname{enList(i)},MPSNRALL(enList(i)), SSIMALL(enList(i)),0,time(i));
        %% Perform  algorithms
         %% Use TNN
        i = 2;
        if EN_TNN
            enList = [enList,i];
            % initialization of the parameters
            kkk = 0;
            opts = [];
            opts.DEBUG = 0;
            opts.Xtrue = Y_tensorT;
            opts.max_beta = 1e10;
            opts.maxit = 500;
            for op_beta = [1 ]*10.^-2
                kkk =  kkk+1;
                opts.beta = op_beta;
                opts.tol = 1e-3;
                opts.rho = 1.1;
                opts_All{kkk} = opts;
            end
            
            PSNRALL1 = zeros(kkk,1);PSNRALLS = zeros(kkk,1);
            SSIMALL1 = zeros(kkk,1);SSIMALLS = zeros(kkk,1);
            for ii = 1:kkk
                tStart = tic;
                opts = opts_All{ii};
                [Re_tensor{i},Out,iterations] = TC_TNN(Y_tensor0,Omega,opts);
                time(i)= toc(tStart);
                iters(i) = iterations;
                [MPSNRALL(i), SSIMALL(i)] = quality(Y_tensorT*255, Re_tensor{i}*255);
                PSNRALL1(ii) = MPSNRALL(i);
                SSIMALL1(ii) = SSIMALL(i);
                fprintf(' %8.8s    %5.3f    %5.4f    %3d     %.1f | my = %.3f   rho = %.3f \n',...
                    methodname{i},MPSNRALL(i), SSIMALL(i),iters(i),time(i),opts.beta,opts.rho);
            end
        end
         %% Use UTNN
        i = 3;
            if EN_UTNN
            enList = [enList,i];
            % initialization of the parameters
            kkk = 0;
            opts = [];
            opts.gamma = 1.1;
            opts.Xtrue = Y_tensorT;
            opts.max_beta = 1e10;
            opts.MaxIte = 500;
            % Initialize the unitary transform
            U0 = Re_tensor{2};
            O = tenmat(U0,3); % unfolding
            O = O.data;
            [U, ~ ,~] = svd(O,'econ');
            for beta = [ 10^-1]               
                    kkk =  kkk+1;
                    opts.beta = beta;
                    opts.tol = 5e-4;
                    opts_All{kkk} = opts;
            end            
            PSNRALL1 = zeros(kkk,1);PSNRALLS = zeros(kkk,1);
            SSIMALL1 = zeros(kkk,1);SSIMALLS = zeros(kkk,1);
            for ii = 1:kkk
                tStart = tic;
                opts = opts_All{ii};
                opts.Xtrue = Y_tensorT;
                [Re_tensor{i},iterations] = TC_UTNN(U,Y_tensor0,Omega,opts);
                time(i)= toc(tStart);
                iters(i) = iterations;
                [MPSNRALL(i), SSIMALL(i)] = quality(Y_tensorT * 255, Re_tensor{i} * 255);
                PSNRALL1(ii) = MPSNRALL(i);
                SSIMALL1(ii) = SSIMALL(i);
                fprintf(' %8.8s    %5.3f    %5.4f   %3d     %.1f | beta = %.3f \n',...
                    methodname{i},MPSNRALL(i), SSIMALL(i),iters(i),time(i),opts.beta);
            end
            end
        %% Use FTNN
         i = 4;
        if EN_FTNN
            enList = [enList,i];
        %parameters
        opts.Frame    = 1; % (0,1,3)
        opts.Level    = 4;  % [1,2,3,4,5,6]
        opts.wLevel   = -1;
        opts.lambda1  = 1;
        opts.beta     = 1;
        opts.tol      = 1e-2;
        opts.rho      = 1;
        opts.DEBUG    = 0;
        opts.max_iter = 100;
        opts.max_beta = 1e10;
        tStart = tic;
        [X_out,iter] = TC_FTNN(Y_tensor0,Omega,opts,X);
        Re_tensor{i} = X_out;
        time(i)= toc(tStart);
        iters(i) = iter;
        [MPSNRALL(i), SSIMALL(i)] = quality(Y_tensorT*255, Re_tensor{i}*255);
        fprintf(' %8.8s    %5.3f    %5.3f    %3.3d   %.1f | Frame =  %d, Level = %d, beta = %.2f\n',...
            methodname{i},MPSNRALL(i), SSIMALL(i),iters(i),time(i),...
            opts.Frame,opts.Level,opts.beta);        
    end
        %% Use NTTNN
        i = 5;
        if EN_NTTNN
            enList = [enList,i];
           % interpolation
            A = Y_tensor0;
            B = padarray(A,[20,20,20],'symmetric','both');
            C = padarray(Ind,[20,20,20],'symmetric','both');
            a1 = interpolate(shiftdim(B,1),shiftdim(C,1));
            a1(a1<0) = 0;
            a1(a1>1) = 1;
            a1 = a1(21:end-20,21:end-20,21:end-20);
            a1 = shiftdim(a1,2);
            a1(Omega) = Y_tensorT(Omega);
            a2 = interpolate(shiftdim(B,2),shiftdim(C,2));
            a2(a2<0) = 0;
            a2(a2>1) = 1;
            a2 = a2(21:end-20,21:end-20,21:end-20);
            a2 = shiftdim(a2,1);
            a2(Omega) = Y_tensorT(Omega);
            a3(Omega) = Y_tensorT(Omega);
            a = 0.5*a1+0.5*a2;
            X0 = a;
            X0(Omega) = Y_tensorT(Omega);
            
            kkk = 0;
            opts   = [];
            for alpha = [10 ]
                for beta = [10]
                    for d = [20]
                        rho = 0.01;
                        kkk = kkk+1;
                        X_m = Unfold(X0,size(X0),3);
                        Ind_m = Unfold(Ind,size(Ind),1);
                        Ind   = sum(Ind_m,1);
                        [~,D_omega] = sort(Ind(:),'descend');
                        [DI,~,~] = svds(X_m,d);
                        opts = [];
                        opts.D0  = DI;
                        opts.d   = d;
                        opts.rho = rho;
                        opts.tol = 10^-4;
                        opts.max_iter = 500;
                        opts.inner = 10;
                        opts.alpha = alpha;
                        opts.beta = beta;
                        opts_All{kkk} = opts;
                    end
                end
            end
        end
                
                for ii = 1:kkk
                    tStart = tic;
                    opts = opts_All{ii};
                    [Re_tensor{i},iter] = TC_NTTNN(Omega,opts,Y_tensorT,X0);
                    time(i)= toc(tStart);
                    iters(i) = iter;
                    [MPSNRALL(i), SSIMALL(i)] = quality(Y_tensorT*255, Re_tensor{i}*255);
                    PSNRALL1(ii) = MPSNRALL(i);
                    SSIMALL1(ii) = SSIMALL(i);
                    fprintf(' %8.8s    %5.3f    %5.4f    %3d     %.1f | alpha = %.1f beta = %.3f  d = %.0f  rho = %.2f  \n',...
                        methodname{i},MPSNRALL(i),SSIMALL(i),iters(i),time(i),opts.alpha,opts.beta,opts.d,opts.rho);
                end
    end        
    %% Show results
    fprintf('\n');
    fprintf('================== Result =====================\n');
    fprintf(' %8.8s    %5.4s    %5.4s    %5.4s  %5.4s \n','method','PSNR', 'SSIM', 'iter','time');
    for i = enList
        fprintf(' %8.8s    %5.3f    %5.4f  %3d   %.1f \n',methodname{i},MPSNRALL(i), SSIMALL(i),iters(i),time(i));
    end
    subplot(1,6,1);imshow(Re_tensor{1}(:,:,1),'border','tight','initialmagnification','fit');title('Observed')
    subplot(1,6,2);imshow(Re_tensor{2}(:,:,1),'border','tight','initialmagnification','fit');title('TNN')
    subplot(1,6,3);imshow(Re_tensor{3}(:,:,1),'border','tight','initialmagnification','fit');title('UTNN')
    subplot(1,6,4);imshow(Re_tensor{4}(:,:,1),'border','tight','initialmagnification','fit');title('FTNN')
    subplot(1,6,5);imshow(Re_tensor{5}(:,:,1),'border','tight','initialmagnification','fit');title('NTTNN')
    subplot(1,6,6);imshow(Y_tensorT(:,:,1),'border','tight','initialmagnification','fit');title('Original')
end

