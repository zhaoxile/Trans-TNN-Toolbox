function z = tensor_slice(Z,i,j)
%Input:Z is a three-order tensor
%Output:z is the j-the first slice along the i-th dimension of Z

if i == 1
    z = Z(j,:,:);
elseif i == 2
        z = Z(:,j,:);
elseif  i == 3
      z = Z(:,:,j);
end  
end


