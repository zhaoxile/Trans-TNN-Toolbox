function Z_new = tensor_slice_back(z,i,j,Z_old)
%Input:Z is a three-order tensor
%Output:Z is the j-the first slice along the i-th dimension of Z
if i == 1
    Z_old(j,:,:) = z;
elseif  i == 2
     Z_old(:,j,:) = z;
elseif i == 3
     Z_old(:,:,j) = z;
end
Z_new = Z_old;
    