function X = ConjGrad(A,B,X0,tol,MaxIter)

R0 = B-A*X0;
P0 = R0;
for i = 1:MaxIter
    Alpha = R0(:)'*R0(:)