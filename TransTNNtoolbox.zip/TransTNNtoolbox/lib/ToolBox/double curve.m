x=1:9;
y1=[28.018225,28.4413,28.2052,28.185,27.319475,27.1339,26.9468,27.352475,26.941075];
y2=[0.961975,0.9646,0.96025,0.962125,0.959875,0.95975,0.95915,0.959325,0.9594];

[AX,H1,H2]=plotyy(x,y1,x,y2,'plot');
xlabel('# of Candidate Patches (��)');
set(get(AX(1),'Ylabel'),'string',' PSNR [dB]','FontSize',20);
set(get(AX(2),'Ylabel'),'string',' SSIM','FontWeight','bold','FontSize',20);
set(H1,'LineStyle','--','LineWidth',2);
set(H2,'LineStyle','-','LineWidth',2);
set(gca,'LineWidth',2);
%legend('PSNR','SSIM')