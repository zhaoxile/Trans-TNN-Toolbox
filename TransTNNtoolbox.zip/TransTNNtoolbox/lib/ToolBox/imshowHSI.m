function Z = imshowHSI(X,p,q)
if nargin == 1
   p=2; q=1;
end
if nargin == 2
   q=1;
end

[m,n,k]=size(X);
m1=round(p*m);
n1=round(p*n);
k1=q*k;
Y=zeros(m1,n1,k1);
for i=1:k1
    Y(:,:,i)=imresize(X(:,:,ceil(i/q)),[m1,n1]);
end

Z=ones(m1+k1-1,n1+k1-1);
for i=k1:-1:1
    Z(k1+1-i:k1+1-i+m1-1,i:i+n1-1)=Y(:,:,i);
end
imshow(Z)
end