function [D,R]=GenerateFrameletFilter(frame)
if frame==0          %Haar Wavelet
    D(1,:)=[0 1 1]/2;
    D(2,:)=[0 1 -1]/2;
    R(1,:)=[1 1 0]/2;
    R(2,:)=[-1 1 0]/2;
elseif frame==1      %Piecewise Linear Framelet
    D(1,:)=[1 2 1]/4;
    D(2,:)=[1 0 -1]/4*sqrt(2);
    D(3,:)=[-1 2 -1]/4;
    R(1,:)=[1 2 1]/4;
    R(2,:)=[-1 0 1]/4*sqrt(2);
    R(3,:)=[-1 2 -1]/4;
elseif frame==3      %Piecewise Cubic Framelet
    D(1,:)=[1 4 6 4 1]/16;
    D(2,:)=[1 2 0 -2 -1]/8;
    D(3,:)=[-1 0 2 0 -1]/16*sqrt(6);
    D(4,:)=[-1 2 0 -2 1]/8;
    D(5,:)=[1 -4 6 -4 1]/16;
    R(1,:)=[1 4 6 4 1]/16;
    R(2,:)=[-1 -2 0 2 1]/8;
    R(3,:)=[-1 0 2 0 -1]/16*sqrt(6);
    R(4,:)=[1 -2 0 2 -1]/8;
    R(5,:)=[1 -4 6 -4 1]/16;
end